
using System;

class Hello
{

    static void Main(string[] args)
    {

        var i = 10;  // when we don't know the data type of a variable
        var name = "Harish";

        Console.WriteLine(i + " " + name);
    }
}