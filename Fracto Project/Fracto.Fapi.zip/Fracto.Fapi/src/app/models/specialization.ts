export interface Specialization {
  specializationId: number;
  specializationName: string;
}
