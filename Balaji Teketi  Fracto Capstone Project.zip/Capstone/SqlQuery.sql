CREATE TABLE users (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Role NVARCHAR(20) NOT NULL CHECK (Role IN ('Admin', 'User'))
);

INSERT INTO Users (Username, PasswordHash, Role)
VALUES ('admin', 'admin123', 'Admin');


CREATE TABLE Specializations (
    SpecializationId INT PRIMARY KEY IDENTITY(1,1),
    SpecializationName NVARCHAR(100) NOT NULL
);

INSERT INTO Specializations (SpecializationName) VALUES
('Cardiologist'),
('Dermatologist'),
('Pediatrician'),
('Orthopedic');


CREATE TABLE Doctors (
    DoctorId INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    SpecializationId INT NOT NULL,
    Rating DECIMAL(3,2) NULL DEFAULT 0,  -- e.g. 4.25 rating
    CONSTRAINT FK_Doctor_Specialization FOREIGN KEY (SpecializationId)
        REFERENCES Specializations(SpecializationId)
);

INSERT INTO Doctors (Name, City, SpecializationId, Rating) VALUES
('Dr. Arjun Mehta', 'Mumbai', 1, 4.5),
('Dr. Priya Nair', 'Delhi', 2, 4.2),
('Dr. Rakesh Sharma', 'Bangalore', 3, 3.8),
('Dr. Sneha Gupta', 'Chennai', 4, 4.7);


CREATE TABLE Ratings (
    RatingId INT PRIMARY KEY IDENTITY(1,1),
    DoctorId INT NOT NULL,
    UserId INT NOT NULL,
    Value INT CHECK (Value BETWEEN 1 AND 5)


    CREATE TABLE Appointments (
    AppointmentId INT PRIMARY KEY IDENTITY(1,1),
    UserId INT NOT NULL,
    DoctorId INT NOT NULL,
    AppointmentDate DATETIME NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',  
    CONSTRAINT FK_Appointment_User FOREIGN KEY (UserId) REFERENCES Users(UserId),
    CONSTRAINT FK_Appointment_Doctor FOREIGN KEY (DoctorId) REFERENCES Doctors(DoctorId)
);









